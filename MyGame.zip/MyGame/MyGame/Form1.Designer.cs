﻿namespace MyGame
{
    partial class frmMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcMatchtheFacts = new System.Windows.Forms.TabControl();
            this.tbcSplashScreen = new System.Windows.Forms.TabPage();
            this.btnProceedtoGame = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lblGame = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tbcIntroduction = new System.Windows.Forms.TabPage();
            this.btnProceedtoDifficulty = new System.Windows.Forms.Button();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.tbcDifficulty = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHard = new System.Windows.Forms.Button();
            this.btnEasy = new System.Windows.Forms.Button();
            this.tbcEasy = new System.Windows.Forms.TabPage();
            this.btnProceed = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbcQ1 = new System.Windows.Forms.TabPage();
            this.btnProceedQ2 = new System.Windows.Forms.Button();
            this.rbtnChoice4 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice3 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice2 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEasy1 = new System.Windows.Forms.TextBox();
            this.tbcQ2 = new System.Windows.Forms.TabPage();
            this.btnFinalEasy = new System.Windows.Forms.Button();
            this.rbtnChoice6 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice7 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice8 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice5 = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblEasy2 = new System.Windows.Forms.Label();
            this.tbcQ3 = new System.Windows.Forms.TabPage();
            this.btnFinalEasyQuestion = new System.Windows.Forms.Button();
            this.rbtnChoice12 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice11 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice10 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice9 = new System.Windows.Forms.RadioButton();
            this.txtEasyFinal = new System.Windows.Forms.TextBox();
            this.lblEasy3 = new System.Windows.Forms.Label();
            this.tbcEasyCompletion = new System.Windows.Forms.TabPage();
            this.btnLeaderboard = new System.Windows.Forms.Button();
            this.btnProceedtoMedium = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbcHard = new System.Windows.Forms.TabPage();
            this.btnProceedtoHard = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbcHardQ1 = new System.Windows.Forms.TabPage();
            this.btnNextQuestion = new System.Windows.Forms.Button();
            this.rbtnChoice16 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice15 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice14 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice13 = new System.Windows.Forms.RadioButton();
            this.txtHardQ1 = new System.Windows.Forms.TextBox();
            this.lblHardQ1 = new System.Windows.Forms.Label();
            this.tbcHardQ2 = new System.Windows.Forms.TabPage();
            this.btnFinalQuestion = new System.Windows.Forms.Button();
            this.rbtnChoice20 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice18 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice19 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice17 = new System.Windows.Forms.RadioButton();
            this.txtHardQ2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbcHardQ3 = new System.Windows.Forms.TabPage();
            this.btnAccessLeaderboard = new System.Windows.Forms.Button();
            this.rbtnChoice24 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice23 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice22 = new System.Windows.Forms.RadioButton();
            this.rbtnChoice21 = new System.Windows.Forms.RadioButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbcLeaderboard = new System.Windows.Forms.TabPage();
            this.gbxOverall = new System.Windows.Forms.GroupBox();
            this.txtOverall = new System.Windows.Forms.TextBox();
            this.gbxIndividual = new System.Windows.Forms.GroupBox();
            this.txtIndividual = new System.Windows.Forms.TextBox();
            this.lblEasyStage = new System.Windows.Forms.Label();
            this.tbcMatchtheFacts.SuspendLayout();
            this.tbcSplashScreen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tbcIntroduction.SuspendLayout();
            this.tbcDifficulty.SuspendLayout();
            this.tbcEasy.SuspendLayout();
            this.tbcQ1.SuspendLayout();
            this.tbcQ2.SuspendLayout();
            this.tbcQ3.SuspendLayout();
            this.tbcEasyCompletion.SuspendLayout();
            this.tbcHard.SuspendLayout();
            this.tbcHardQ1.SuspendLayout();
            this.tbcHardQ2.SuspendLayout();
            this.tbcHardQ3.SuspendLayout();
            this.tbcLeaderboard.SuspendLayout();
            this.gbxOverall.SuspendLayout();
            this.gbxIndividual.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcMatchtheFacts
            // 
            this.tbcMatchtheFacts.Controls.Add(this.tbcSplashScreen);
            this.tbcMatchtheFacts.Controls.Add(this.tbcIntroduction);
            this.tbcMatchtheFacts.Controls.Add(this.tbcDifficulty);
            this.tbcMatchtheFacts.Controls.Add(this.tbcEasy);
            this.tbcMatchtheFacts.Controls.Add(this.tbcQ1);
            this.tbcMatchtheFacts.Controls.Add(this.tbcQ2);
            this.tbcMatchtheFacts.Controls.Add(this.tbcQ3);
            this.tbcMatchtheFacts.Controls.Add(this.tbcEasyCompletion);
            this.tbcMatchtheFacts.Controls.Add(this.tbcHard);
            this.tbcMatchtheFacts.Controls.Add(this.tbcHardQ1);
            this.tbcMatchtheFacts.Controls.Add(this.tbcHardQ2);
            this.tbcMatchtheFacts.Controls.Add(this.tbcHardQ3);
            this.tbcMatchtheFacts.Controls.Add(this.tbcLeaderboard);
            this.tbcMatchtheFacts.Location = new System.Drawing.Point(4, 2);
            this.tbcMatchtheFacts.Name = "tbcMatchtheFacts";
            this.tbcMatchtheFacts.SelectedIndex = 0;
            this.tbcMatchtheFacts.Size = new System.Drawing.Size(923, 341);
            this.tbcMatchtheFacts.TabIndex = 0;
            // 
            // tbcSplashScreen
            // 
            this.tbcSplashScreen.Controls.Add(this.btnProceedtoGame);
            this.tbcSplashScreen.Controls.Add(this.textBox4);
            this.tbcSplashScreen.Controls.Add(this.lblGame);
            this.tbcSplashScreen.Controls.Add(this.pictureBox1);
            this.tbcSplashScreen.Location = new System.Drawing.Point(4, 22);
            this.tbcSplashScreen.Name = "tbcSplashScreen";
            this.tbcSplashScreen.Padding = new System.Windows.Forms.Padding(3);
            this.tbcSplashScreen.Size = new System.Drawing.Size(952, 315);
            this.tbcSplashScreen.TabIndex = 13;
            this.tbcSplashScreen.Text = "Splash Screen";
            this.tbcSplashScreen.UseVisualStyleBackColor = true;
            // 
            // btnProceedtoGame
            // 
            this.btnProceedtoGame.Location = new System.Drawing.Point(324, 171);
            this.btnProceedtoGame.Name = "btnProceedtoGame";
            this.btnProceedtoGame.Size = new System.Drawing.Size(379, 97);
            this.btnProceedtoGame.TabIndex = 3;
            this.btnProceedtoGame.Text = "Proceed to Game";
            this.btnProceedtoGame.UseVisualStyleBackColor = true;
            this.btnProceedtoGame.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceedtoGame_MouseClick);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(324, 83);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(379, 81);
            this.textBox4.TabIndex = 2;
            this.textBox4.Text = "This is a game in which you have answer three questions in two categories:\r\nEasy " +
    "& Hard\r\n\r\nThe aim of the game is to get a higher score each time you attempt  th" +
    "e game. \r\n\r\n";
            // 
            // lblGame
            // 
            this.lblGame.AutoSize = true;
            this.lblGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGame.Location = new System.Drawing.Point(319, 54);
            this.lblGame.Name = "lblGame";
            this.lblGame.Size = new System.Drawing.Size(318, 25);
            this.lblGame.TabIndex = 1;
            this.lblGame.Text = "Welcome to Match the Facts!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MyGame.Properties.Resources.match_the_facts_logo;
            this.pictureBox1.Location = new System.Drawing.Point(7, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(939, 307);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tbcIntroduction
            // 
            this.tbcIntroduction.Controls.Add(this.btnProceedtoDifficulty);
            this.tbcIntroduction.Controls.Add(this.txtUsername);
            this.tbcIntroduction.Controls.Add(this.lblUsername);
            this.tbcIntroduction.Controls.Add(this.lblTitle);
            this.tbcIntroduction.Location = new System.Drawing.Point(4, 22);
            this.tbcIntroduction.Name = "tbcIntroduction";
            this.tbcIntroduction.Padding = new System.Windows.Forms.Padding(3);
            this.tbcIntroduction.Size = new System.Drawing.Size(952, 315);
            this.tbcIntroduction.TabIndex = 0;
            this.tbcIntroduction.Text = "Match the Facts";
            this.tbcIntroduction.UseVisualStyleBackColor = true;
            // 
            // btnProceedtoDifficulty
            // 
            this.btnProceedtoDifficulty.Location = new System.Drawing.Point(261, 90);
            this.btnProceedtoDifficulty.Name = "btnProceedtoDifficulty";
            this.btnProceedtoDifficulty.Size = new System.Drawing.Size(352, 87);
            this.btnProceedtoDifficulty.TabIndex = 3;
            this.btnProceedtoDifficulty.Text = "Proceed to Difficulty Selection";
            this.btnProceedtoDifficulty.UseVisualStyleBackColor = true;
            this.btnProceedtoDifficulty.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceedtoDifficulty_MouseClick);
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(261, 51);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(352, 20);
            this.txtUsername.TabIndex = 2;
            this.txtUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(196, 51);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(58, 13);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Username:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(368, 16);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(128, 20);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Match the Facts:";
            // 
            // tbcDifficulty
            // 
            this.tbcDifficulty.Controls.Add(this.label1);
            this.tbcDifficulty.Controls.Add(this.btnHard);
            this.tbcDifficulty.Controls.Add(this.btnEasy);
            this.tbcDifficulty.Location = new System.Drawing.Point(4, 22);
            this.tbcDifficulty.Name = "tbcDifficulty";
            this.tbcDifficulty.Padding = new System.Windows.Forms.Padding(3);
            this.tbcDifficulty.Size = new System.Drawing.Size(952, 315);
            this.tbcDifficulty.TabIndex = 1;
            this.tbcDifficulty.Text = "Difficulty Selection";
            this.tbcDifficulty.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(365, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Difficulty Selection:";
            // 
            // btnHard
            // 
            this.btnHard.Location = new System.Drawing.Point(368, 132);
            this.btnHard.Name = "btnHard";
            this.btnHard.Size = new System.Drawing.Size(162, 115);
            this.btnHard.TabIndex = 2;
            this.btnHard.Text = "Hard";
            this.btnHard.UseVisualStyleBackColor = true;
            this.btnHard.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnHard_MouseClick);
            // 
            // btnEasy
            // 
            this.btnEasy.Location = new System.Drawing.Point(369, 50);
            this.btnEasy.Name = "btnEasy";
            this.btnEasy.Size = new System.Drawing.Size(161, 76);
            this.btnEasy.TabIndex = 0;
            this.btnEasy.Text = "Easy";
            this.btnEasy.UseVisualStyleBackColor = true;
            this.btnEasy.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnEasy_MouseClick);
            // 
            // tbcEasy
            // 
            this.tbcEasy.Controls.Add(this.btnProceed);
            this.tbcEasy.Controls.Add(this.label3);
            this.tbcEasy.Controls.Add(this.label2);
            this.tbcEasy.Location = new System.Drawing.Point(4, 22);
            this.tbcEasy.Name = "tbcEasy";
            this.tbcEasy.Padding = new System.Windows.Forms.Padding(3);
            this.tbcEasy.Size = new System.Drawing.Size(952, 315);
            this.tbcEasy.TabIndex = 2;
            this.tbcEasy.Text = "Easy";
            this.tbcEasy.UseVisualStyleBackColor = true;
            // 
            // btnProceed
            // 
            this.btnProceed.Location = new System.Drawing.Point(312, 100);
            this.btnProceed.Name = "btnProceed";
            this.btnProceed.Size = new System.Drawing.Size(301, 72);
            this.btnProceed.TabIndex = 2;
            this.btnProceed.Text = "Proceed to Questions";
            this.btnProceed.UseVisualStyleBackColor = true;
            this.btnProceed.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceed_MouseClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(309, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(304, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Please Proceed to the set of Easy Questions";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(346, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Difficulty Selection: Easy";
            // 
            // tbcQ1
            // 
            this.tbcQ1.Controls.Add(this.btnProceedQ2);
            this.tbcQ1.Controls.Add(this.rbtnChoice4);
            this.tbcQ1.Controls.Add(this.rbtnChoice3);
            this.tbcQ1.Controls.Add(this.rbtnChoice2);
            this.tbcQ1.Controls.Add(this.rbtnChoice1);
            this.tbcQ1.Controls.Add(this.label4);
            this.tbcQ1.Controls.Add(this.txtEasy1);
            this.tbcQ1.Location = new System.Drawing.Point(4, 22);
            this.tbcQ1.Name = "tbcQ1";
            this.tbcQ1.Padding = new System.Windows.Forms.Padding(3);
            this.tbcQ1.Size = new System.Drawing.Size(952, 315);
            this.tbcQ1.TabIndex = 6;
            this.tbcQ1.Text = "Easy Q1";
            this.tbcQ1.UseVisualStyleBackColor = true;
            // 
            // btnProceedQ2
            // 
            this.btnProceedQ2.Location = new System.Drawing.Point(249, 210);
            this.btnProceedQ2.Name = "btnProceedQ2";
            this.btnProceedQ2.Size = new System.Drawing.Size(346, 57);
            this.btnProceedQ2.TabIndex = 6;
            this.btnProceedQ2.Text = "Proceed to Question 2";
            this.btnProceedQ2.UseVisualStyleBackColor = true;
            this.btnProceedQ2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceedQ2_MouseClick);
            // 
            // rbtnChoice4
            // 
            this.rbtnChoice4.AutoSize = true;
            this.rbtnChoice4.Location = new System.Drawing.Point(249, 172);
            this.rbtnChoice4.Name = "rbtnChoice4";
            this.rbtnChoice4.Size = new System.Drawing.Size(49, 17);
            this.rbtnChoice4.TabIndex = 5;
            this.rbtnChoice4.TabStop = true;
            this.rbtnChoice4.Text = "1988";
            this.rbtnChoice4.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice3
            // 
            this.rbtnChoice3.AutoSize = true;
            this.rbtnChoice3.Location = new System.Drawing.Point(249, 149);
            this.rbtnChoice3.Name = "rbtnChoice3";
            this.rbtnChoice3.Size = new System.Drawing.Size(49, 17);
            this.rbtnChoice3.TabIndex = 4;
            this.rbtnChoice3.TabStop = true;
            this.rbtnChoice3.Text = "1995";
            this.rbtnChoice3.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice2
            // 
            this.rbtnChoice2.AutoSize = true;
            this.rbtnChoice2.Location = new System.Drawing.Point(249, 126);
            this.rbtnChoice2.Name = "rbtnChoice2";
            this.rbtnChoice2.Size = new System.Drawing.Size(49, 17);
            this.rbtnChoice2.TabIndex = 3;
            this.rbtnChoice2.TabStop = true;
            this.rbtnChoice2.Text = "1992";
            this.rbtnChoice2.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice1
            // 
            this.rbtnChoice1.AutoSize = true;
            this.rbtnChoice1.Location = new System.Drawing.Point(249, 103);
            this.rbtnChoice1.Name = "rbtnChoice1";
            this.rbtnChoice1.Size = new System.Drawing.Size(49, 17);
            this.rbtnChoice1.TabIndex = 2;
            this.rbtnChoice1.TabStop = true;
            this.rbtnChoice1.Text = "1991";
            this.rbtnChoice1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(368, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Easy - Question 1:";
            // 
            // txtEasy1
            // 
            this.txtEasy1.Location = new System.Drawing.Point(249, 70);
            this.txtEasy1.Name = "txtEasy1";
            this.txtEasy1.ReadOnly = true;
            this.txtEasy1.Size = new System.Drawing.Size(346, 20);
            this.txtEasy1.TabIndex = 0;
            // 
            // tbcQ2
            // 
            this.tbcQ2.Controls.Add(this.btnFinalEasy);
            this.tbcQ2.Controls.Add(this.rbtnChoice6);
            this.tbcQ2.Controls.Add(this.rbtnChoice7);
            this.tbcQ2.Controls.Add(this.rbtnChoice8);
            this.tbcQ2.Controls.Add(this.rbtnChoice5);
            this.tbcQ2.Controls.Add(this.textBox2);
            this.tbcQ2.Controls.Add(this.lblEasy2);
            this.tbcQ2.Location = new System.Drawing.Point(4, 22);
            this.tbcQ2.Name = "tbcQ2";
            this.tbcQ2.Padding = new System.Windows.Forms.Padding(3);
            this.tbcQ2.Size = new System.Drawing.Size(952, 315);
            this.tbcQ2.TabIndex = 5;
            this.tbcQ2.Text = "Easy Q2";
            this.tbcQ2.UseVisualStyleBackColor = true;
            // 
            // btnFinalEasy
            // 
            this.btnFinalEasy.Location = new System.Drawing.Point(242, 195);
            this.btnFinalEasy.Name = "btnFinalEasy";
            this.btnFinalEasy.Size = new System.Drawing.Size(399, 70);
            this.btnFinalEasy.TabIndex = 6;
            this.btnFinalEasy.Text = "Proceed to Final Easy Question";
            this.btnFinalEasy.UseVisualStyleBackColor = true;
            this.btnFinalEasy.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnFinalEasy_MouseClick);
            // 
            // rbtnChoice6
            // 
            this.rbtnChoice6.AutoSize = true;
            this.rbtnChoice6.Location = new System.Drawing.Point(242, 114);
            this.rbtnChoice6.Name = "rbtnChoice6";
            this.rbtnChoice6.Size = new System.Drawing.Size(96, 17);
            this.rbtnChoice6.TabIndex = 5;
            this.rbtnChoice6.TabStop = true;
            this.rbtnChoice6.Text = "Steve Sinsofky";
            this.rbtnChoice6.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice7
            // 
            this.rbtnChoice7.AutoSize = true;
            this.rbtnChoice7.Location = new System.Drawing.Point(242, 137);
            this.rbtnChoice7.Name = "rbtnChoice7";
            this.rbtnChoice7.Size = new System.Drawing.Size(75, 17);
            this.rbtnChoice7.TabIndex = 4;
            this.rbtnChoice7.TabStop = true;
            this.rbtnChoice7.Text = "Elon Musk";
            this.rbtnChoice7.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice8
            // 
            this.rbtnChoice8.AutoSize = true;
            this.rbtnChoice8.Location = new System.Drawing.Point(242, 160);
            this.rbtnChoice8.Name = "rbtnChoice8";
            this.rbtnChoice8.Size = new System.Drawing.Size(69, 17);
            this.rbtnChoice8.TabIndex = 3;
            this.rbtnChoice8.TabStop = true;
            this.rbtnChoice8.Text = "Bill Gates";
            this.rbtnChoice8.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice5
            // 
            this.rbtnChoice5.AutoSize = true;
            this.rbtnChoice5.Location = new System.Drawing.Point(242, 91);
            this.rbtnChoice5.Name = "rbtnChoice5";
            this.rbtnChoice5.Size = new System.Drawing.Size(93, 17);
            this.rbtnChoice5.TabIndex = 2;
            this.rbtnChoice5.TabStop = true;
            this.rbtnChoice5.Text = "Steve  Ballmer";
            this.rbtnChoice5.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(242, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(399, 20);
            this.textBox2.TabIndex = 1;
            // 
            // lblEasy2
            // 
            this.lblEasy2.AutoSize = true;
            this.lblEasy2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEasy2.Location = new System.Drawing.Point(368, 14);
            this.lblEasy2.Name = "lblEasy2";
            this.lblEasy2.Size = new System.Drawing.Size(134, 20);
            this.lblEasy2.TabIndex = 0;
            this.lblEasy2.Text = "Easy - Question 2";
            // 
            // tbcQ3
            // 
            this.tbcQ3.Controls.Add(this.btnFinalEasyQuestion);
            this.tbcQ3.Controls.Add(this.rbtnChoice12);
            this.tbcQ3.Controls.Add(this.rbtnChoice11);
            this.tbcQ3.Controls.Add(this.rbtnChoice10);
            this.tbcQ3.Controls.Add(this.rbtnChoice9);
            this.tbcQ3.Controls.Add(this.txtEasyFinal);
            this.tbcQ3.Controls.Add(this.lblEasy3);
            this.tbcQ3.Location = new System.Drawing.Point(4, 22);
            this.tbcQ3.Name = "tbcQ3";
            this.tbcQ3.Padding = new System.Windows.Forms.Padding(3);
            this.tbcQ3.Size = new System.Drawing.Size(952, 315);
            this.tbcQ3.TabIndex = 7;
            this.tbcQ3.Text = "Easy Q3";
            this.tbcQ3.UseVisualStyleBackColor = true;
            // 
            // btnFinalEasyQuestion
            // 
            this.btnFinalEasyQuestion.Location = new System.Drawing.Point(191, 175);
            this.btnFinalEasyQuestion.Name = "btnFinalEasyQuestion";
            this.btnFinalEasyQuestion.Size = new System.Drawing.Size(433, 92);
            this.btnFinalEasyQuestion.TabIndex = 6;
            this.btnFinalEasyQuestion.Text = "Complete Easy Questions";
            this.btnFinalEasyQuestion.UseVisualStyleBackColor = true;
            this.btnFinalEasyQuestion.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnFinalEasyQuestion_MouseClick);
            // 
            // rbtnChoice12
            // 
            this.rbtnChoice12.AutoSize = true;
            this.rbtnChoice12.Location = new System.Drawing.Point(191, 151);
            this.rbtnChoice12.Name = "rbtnChoice12";
            this.rbtnChoice12.Size = new System.Drawing.Size(75, 17);
            this.rbtnChoice12.TabIndex = 5;
            this.rbtnChoice12.TabStop = true;
            this.rbtnChoice12.Text = "Elon Musk";
            this.rbtnChoice12.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice11
            // 
            this.rbtnChoice11.AutoSize = true;
            this.rbtnChoice11.Location = new System.Drawing.Point(191, 128);
            this.rbtnChoice11.Name = "rbtnChoice11";
            this.rbtnChoice11.Size = new System.Drawing.Size(74, 17);
            this.rbtnChoice11.TabIndex = 4;
            this.rbtnChoice11.TabStop = true;
            this.rbtnChoice11.Text = "Jeff Bezos";
            this.rbtnChoice11.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice10
            // 
            this.rbtnChoice10.AutoSize = true;
            this.rbtnChoice10.Location = new System.Drawing.Point(191, 105);
            this.rbtnChoice10.Name = "rbtnChoice10";
            this.rbtnChoice10.Size = new System.Drawing.Size(107, 17);
            this.rbtnChoice10.TabIndex = 3;
            this.rbtnChoice10.TabStop = true;
            this.rbtnChoice10.Text = "Mark Zuckerberg";
            this.rbtnChoice10.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice9
            // 
            this.rbtnChoice9.AutoSize = true;
            this.rbtnChoice9.Location = new System.Drawing.Point(191, 82);
            this.rbtnChoice9.Name = "rbtnChoice9";
            this.rbtnChoice9.Size = new System.Drawing.Size(78, 17);
            this.rbtnChoice9.TabIndex = 2;
            this.rbtnChoice9.TabStop = true;
            this.rbtnChoice9.Text = "Steve Jobs";
            this.rbtnChoice9.UseVisualStyleBackColor = true;
            // 
            // txtEasyFinal
            // 
            this.txtEasyFinal.Location = new System.Drawing.Point(191, 46);
            this.txtEasyFinal.Name = "txtEasyFinal";
            this.txtEasyFinal.ReadOnly = true;
            this.txtEasyFinal.Size = new System.Drawing.Size(433, 20);
            this.txtEasyFinal.TabIndex = 1;
            // 
            // lblEasy3
            // 
            this.lblEasy3.AutoSize = true;
            this.lblEasy3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEasy3.Location = new System.Drawing.Point(339, 19);
            this.lblEasy3.Name = "lblEasy3";
            this.lblEasy3.Size = new System.Drawing.Size(163, 20);
            this.lblEasy3.TabIndex = 0;
            this.lblEasy3.Text = "Easy - Final Question:";
            // 
            // tbcEasyCompletion
            // 
            this.tbcEasyCompletion.Controls.Add(this.lblEasyStage);
            this.tbcEasyCompletion.Controls.Add(this.btnLeaderboard);
            this.tbcEasyCompletion.Controls.Add(this.btnProceedtoMedium);
            this.tbcEasyCompletion.Controls.Add(this.btnClose);
            this.tbcEasyCompletion.Location = new System.Drawing.Point(4, 22);
            this.tbcEasyCompletion.Name = "tbcEasyCompletion";
            this.tbcEasyCompletion.Padding = new System.Windows.Forms.Padding(3);
            this.tbcEasyCompletion.Size = new System.Drawing.Size(952, 315);
            this.tbcEasyCompletion.TabIndex = 9;
            this.tbcEasyCompletion.Text = "Easy Stage Completed";
            this.tbcEasyCompletion.UseVisualStyleBackColor = true;
            // 
            // btnLeaderboard
            // 
            this.btnLeaderboard.Location = new System.Drawing.Point(332, 206);
            this.btnLeaderboard.Name = "btnLeaderboard";
            this.btnLeaderboard.Size = new System.Drawing.Size(234, 84);
            this.btnLeaderboard.TabIndex = 3;
            this.btnLeaderboard.Text = "Access Leaderboard";
            this.btnLeaderboard.UseVisualStyleBackColor = true;
            this.btnLeaderboard.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnLeaderboard_MouseClick_1);
            // 
            // btnProceedtoMedium
            // 
            this.btnProceedtoMedium.Location = new System.Drawing.Point(332, 123);
            this.btnProceedtoMedium.Name = "btnProceedtoMedium";
            this.btnProceedtoMedium.Size = new System.Drawing.Size(234, 77);
            this.btnProceedtoMedium.TabIndex = 1;
            this.btnProceedtoMedium.Text = "Proceed to Hard Questions";
            this.btnProceedtoMedium.UseVisualStyleBackColor = true;
            this.btnProceedtoMedium.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceedtoMedium_MouseClick);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(332, 40);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(234, 77);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close Program";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnClose_MouseClick);
            // 
            // tbcHard
            // 
            this.tbcHard.Controls.Add(this.btnProceedtoHard);
            this.tbcHard.Controls.Add(this.label6);
            this.tbcHard.Controls.Add(this.label5);
            this.tbcHard.Location = new System.Drawing.Point(4, 22);
            this.tbcHard.Name = "tbcHard";
            this.tbcHard.Padding = new System.Windows.Forms.Padding(3);
            this.tbcHard.Size = new System.Drawing.Size(952, 315);
            this.tbcHard.TabIndex = 4;
            this.tbcHard.Text = "Hard";
            this.tbcHard.UseVisualStyleBackColor = true;
            // 
            // btnProceedtoHard
            // 
            this.btnProceedtoHard.Location = new System.Drawing.Point(340, 86);
            this.btnProceedtoHard.Name = "btnProceedtoHard";
            this.btnProceedtoHard.Size = new System.Drawing.Size(288, 117);
            this.btnProceedtoHard.TabIndex = 2;
            this.btnProceedtoHard.Text = "Proceed to Hard Questions";
            this.btnProceedtoHard.UseVisualStyleBackColor = true;
            this.btnProceedtoHard.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnProceedtoHard_MouseClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(325, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(303, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Please Proceed to the set of Hard Questions";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(371, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Difficulty Selection: Hard";
            // 
            // tbcHardQ1
            // 
            this.tbcHardQ1.Controls.Add(this.btnNextQuestion);
            this.tbcHardQ1.Controls.Add(this.rbtnChoice16);
            this.tbcHardQ1.Controls.Add(this.rbtnChoice15);
            this.tbcHardQ1.Controls.Add(this.rbtnChoice14);
            this.tbcHardQ1.Controls.Add(this.rbtnChoice13);
            this.tbcHardQ1.Controls.Add(this.txtHardQ1);
            this.tbcHardQ1.Controls.Add(this.lblHardQ1);
            this.tbcHardQ1.Location = new System.Drawing.Point(4, 22);
            this.tbcHardQ1.Name = "tbcHardQ1";
            this.tbcHardQ1.Padding = new System.Windows.Forms.Padding(3);
            this.tbcHardQ1.Size = new System.Drawing.Size(915, 315);
            this.tbcHardQ1.TabIndex = 10;
            this.tbcHardQ1.Text = "Hard Q1";
            this.tbcHardQ1.UseVisualStyleBackColor = true;
            // 
            // btnNextQuestion
            // 
            this.btnNextQuestion.Location = new System.Drawing.Point(197, 176);
            this.btnNextQuestion.Name = "btnNextQuestion";
            this.btnNextQuestion.Size = new System.Drawing.Size(305, 84);
            this.btnNextQuestion.TabIndex = 6;
            this.btnNextQuestion.Text = "Proceed to Question 2";
            this.btnNextQuestion.UseVisualStyleBackColor = true;
            this.btnNextQuestion.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnNextQuestion_MouseClick);
            // 
            // rbtnChoice16
            // 
            this.rbtnChoice16.AutoSize = true;
            this.rbtnChoice16.Location = new System.Drawing.Point(197, 152);
            this.rbtnChoice16.Name = "rbtnChoice16";
            this.rbtnChoice16.Size = new System.Drawing.Size(80, 17);
            this.rbtnChoice16.TabIndex = 5;
            this.rbtnChoice16.TabStop = true;
            this.rbtnChoice16.Text = "Steve Mark";
            this.rbtnChoice16.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice15
            // 
            this.rbtnChoice15.AutoSize = true;
            this.rbtnChoice15.Location = new System.Drawing.Point(197, 129);
            this.rbtnChoice15.Name = "rbtnChoice15";
            this.rbtnChoice15.Size = new System.Drawing.Size(78, 17);
            this.rbtnChoice15.TabIndex = 4;
            this.rbtnChoice15.TabStop = true;
            this.rbtnChoice15.Text = "Steve Jobs";
            this.rbtnChoice15.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice14
            // 
            this.rbtnChoice14.AutoSize = true;
            this.rbtnChoice14.Location = new System.Drawing.Point(197, 106);
            this.rbtnChoice14.Name = "rbtnChoice14";
            this.rbtnChoice14.Size = new System.Drawing.Size(91, 17);
            this.rbtnChoice14.TabIndex = 3;
            this.rbtnChoice14.TabStop = true;
            this.rbtnChoice14.Text = "Satya Nadella";
            this.rbtnChoice14.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice13
            // 
            this.rbtnChoice13.AutoSize = true;
            this.rbtnChoice13.Location = new System.Drawing.Point(197, 83);
            this.rbtnChoice13.Name = "rbtnChoice13";
            this.rbtnChoice13.Size = new System.Drawing.Size(72, 17);
            this.rbtnChoice13.TabIndex = 2;
            this.rbtnChoice13.TabStop = true;
            this.rbtnChoice13.Text = "Paul Allen";
            this.rbtnChoice13.UseVisualStyleBackColor = true;
            // 
            // txtHardQ1
            // 
            this.txtHardQ1.Location = new System.Drawing.Point(197, 44);
            this.txtHardQ1.Name = "txtHardQ1";
            this.txtHardQ1.ReadOnly = true;
            this.txtHardQ1.Size = new System.Drawing.Size(469, 20);
            this.txtHardQ1.TabIndex = 1;
            // 
            // lblHardQ1
            // 
            this.lblHardQ1.AutoSize = true;
            this.lblHardQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHardQ1.Location = new System.Drawing.Point(354, 18);
            this.lblHardQ1.Name = "lblHardQ1";
            this.lblHardQ1.Size = new System.Drawing.Size(134, 20);
            this.lblHardQ1.TabIndex = 0;
            this.lblHardQ1.Text = "Hard - Question 1";
            // 
            // tbcHardQ2
            // 
            this.tbcHardQ2.Controls.Add(this.btnFinalQuestion);
            this.tbcHardQ2.Controls.Add(this.rbtnChoice20);
            this.tbcHardQ2.Controls.Add(this.rbtnChoice18);
            this.tbcHardQ2.Controls.Add(this.rbtnChoice19);
            this.tbcHardQ2.Controls.Add(this.rbtnChoice17);
            this.tbcHardQ2.Controls.Add(this.txtHardQ2);
            this.tbcHardQ2.Controls.Add(this.label7);
            this.tbcHardQ2.Location = new System.Drawing.Point(4, 22);
            this.tbcHardQ2.Name = "tbcHardQ2";
            this.tbcHardQ2.Padding = new System.Windows.Forms.Padding(3);
            this.tbcHardQ2.Size = new System.Drawing.Size(952, 315);
            this.tbcHardQ2.TabIndex = 11;
            this.tbcHardQ2.Text = "Hard Q2";
            this.tbcHardQ2.UseVisualStyleBackColor = true;
            // 
            // btnFinalQuestion
            // 
            this.btnFinalQuestion.Location = new System.Drawing.Point(280, 163);
            this.btnFinalQuestion.Name = "btnFinalQuestion";
            this.btnFinalQuestion.Size = new System.Drawing.Size(315, 83);
            this.btnFinalQuestion.TabIndex = 6;
            this.btnFinalQuestion.Text = "Proceed to Final Hard Question";
            this.btnFinalQuestion.UseVisualStyleBackColor = true;
            this.btnFinalQuestion.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnFinalQuestion_MouseClick);
            // 
            // rbtnChoice20
            // 
            this.rbtnChoice20.AutoSize = true;
            this.rbtnChoice20.Location = new System.Drawing.Point(280, 139);
            this.rbtnChoice20.Name = "rbtnChoice20";
            this.rbtnChoice20.Size = new System.Drawing.Size(51, 17);
            this.rbtnChoice20.TabIndex = 5;
            this.rbtnChoice20.TabStop = true;
            this.rbtnChoice20.Text = "Flock";
            this.rbtnChoice20.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice18
            // 
            this.rbtnChoice18.AutoSize = true;
            this.rbtnChoice18.Location = new System.Drawing.Point(280, 93);
            this.rbtnChoice18.Name = "rbtnChoice18";
            this.rbtnChoice18.Size = new System.Drawing.Size(35, 17);
            this.rbtnChoice18.TabIndex = 4;
            this.rbtnChoice18.TabStop = true;
            this.rbtnChoice18.Text = "IE";
            this.rbtnChoice18.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice19
            // 
            this.rbtnChoice19.AutoSize = true;
            this.rbtnChoice19.Location = new System.Drawing.Point(280, 116);
            this.rbtnChoice19.Name = "rbtnChoice19";
            this.rbtnChoice19.Size = new System.Drawing.Size(98, 17);
            this.rbtnChoice19.TabIndex = 3;
            this.rbtnChoice19.TabStop = true;
            this.rbtnChoice19.Text = "Google Chrome";
            this.rbtnChoice19.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice17
            // 
            this.rbtnChoice17.AutoSize = true;
            this.rbtnChoice17.Location = new System.Drawing.Point(280, 70);
            this.rbtnChoice17.Name = "rbtnChoice17";
            this.rbtnChoice17.Size = new System.Drawing.Size(56, 17);
            this.rbtnChoice17.TabIndex = 2;
            this.rbtnChoice17.TabStop = true;
            this.rbtnChoice17.Text = "Firefox";
            this.rbtnChoice17.UseVisualStyleBackColor = true;
            // 
            // txtHardQ2
            // 
            this.txtHardQ2.Location = new System.Drawing.Point(280, 44);
            this.txtHardQ2.Name = "txtHardQ2";
            this.txtHardQ2.ReadOnly = true;
            this.txtHardQ2.Size = new System.Drawing.Size(360, 20);
            this.txtHardQ2.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(384, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Hard - Question 2";
            // 
            // tbcHardQ3
            // 
            this.tbcHardQ3.Controls.Add(this.btnAccessLeaderboard);
            this.tbcHardQ3.Controls.Add(this.rbtnChoice24);
            this.tbcHardQ3.Controls.Add(this.rbtnChoice23);
            this.tbcHardQ3.Controls.Add(this.rbtnChoice22);
            this.tbcHardQ3.Controls.Add(this.rbtnChoice21);
            this.tbcHardQ3.Controls.Add(this.textBox3);
            this.tbcHardQ3.Controls.Add(this.label8);
            this.tbcHardQ3.Location = new System.Drawing.Point(4, 22);
            this.tbcHardQ3.Name = "tbcHardQ3";
            this.tbcHardQ3.Padding = new System.Windows.Forms.Padding(3);
            this.tbcHardQ3.Size = new System.Drawing.Size(952, 315);
            this.tbcHardQ3.TabIndex = 12;
            this.tbcHardQ3.Text = "Hard Q3";
            this.tbcHardQ3.UseVisualStyleBackColor = true;
            // 
            // btnAccessLeaderboard
            // 
            this.btnAccessLeaderboard.Location = new System.Drawing.Point(225, 185);
            this.btnAccessLeaderboard.Name = "btnAccessLeaderboard";
            this.btnAccessLeaderboard.Size = new System.Drawing.Size(378, 99);
            this.btnAccessLeaderboard.TabIndex = 6;
            this.btnAccessLeaderboard.Text = "Access Leaderboards";
            this.btnAccessLeaderboard.UseVisualStyleBackColor = true;
            this.btnAccessLeaderboard.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnAccessLeaderboard_MouseClick);
            // 
            // rbtnChoice24
            // 
            this.rbtnChoice24.AutoSize = true;
            this.rbtnChoice24.Location = new System.Drawing.Point(225, 161);
            this.rbtnChoice24.Name = "rbtnChoice24";
            this.rbtnChoice24.Size = new System.Drawing.Size(93, 17);
            this.rbtnChoice24.TabIndex = 5;
            this.rbtnChoice24.TabStop = true;
            this.rbtnChoice24.Text = "Sunday Pichai";
            this.rbtnChoice24.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice23
            // 
            this.rbtnChoice23.AutoSize = true;
            this.rbtnChoice23.Location = new System.Drawing.Point(225, 138);
            this.rbtnChoice23.Name = "rbtnChoice23";
            this.rbtnChoice23.Size = new System.Drawing.Size(102, 17);
            this.rbtnChoice23.TabIndex = 4;
            this.rbtnChoice23.TabStop = true;
            this.rbtnChoice23.Text = "Tim Berners Lee";
            this.rbtnChoice23.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice22
            // 
            this.rbtnChoice22.AutoSize = true;
            this.rbtnChoice22.Location = new System.Drawing.Point(225, 115);
            this.rbtnChoice22.Name = "rbtnChoice22";
            this.rbtnChoice22.Size = new System.Drawing.Size(115, 17);
            this.rbtnChoice22.TabIndex = 3;
            this.rbtnChoice22.TabStop = true;
            this.rbtnChoice22.Text = "Michael Bloomberg";
            this.rbtnChoice22.UseVisualStyleBackColor = true;
            // 
            // rbtnChoice21
            // 
            this.rbtnChoice21.AutoSize = true;
            this.rbtnChoice21.Location = new System.Drawing.Point(225, 92);
            this.rbtnChoice21.Name = "rbtnChoice21";
            this.rbtnChoice21.Size = new System.Drawing.Size(74, 17);
            this.rbtnChoice21.TabIndex = 2;
            this.rbtnChoice21.TabStop = true;
            this.rbtnChoice21.Text = "Jeff Bezos";
            this.rbtnChoice21.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(225, 55);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(464, 20);
            this.textBox3.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(391, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Hard - Final Question";
            // 
            // tbcLeaderboard
            // 
            this.tbcLeaderboard.Controls.Add(this.gbxOverall);
            this.tbcLeaderboard.Controls.Add(this.gbxIndividual);
            this.tbcLeaderboard.Location = new System.Drawing.Point(4, 22);
            this.tbcLeaderboard.Name = "tbcLeaderboard";
            this.tbcLeaderboard.Padding = new System.Windows.Forms.Padding(3);
            this.tbcLeaderboard.Size = new System.Drawing.Size(952, 315);
            this.tbcLeaderboard.TabIndex = 8;
            this.tbcLeaderboard.Text = "Leaderboards";
            this.tbcLeaderboard.UseVisualStyleBackColor = true;
            // 
            // gbxOverall
            // 
            this.gbxOverall.Controls.Add(this.txtOverall);
            this.gbxOverall.Location = new System.Drawing.Point(368, 25);
            this.gbxOverall.Name = "gbxOverall";
            this.gbxOverall.Size = new System.Drawing.Size(276, 258);
            this.gbxOverall.TabIndex = 2;
            this.gbxOverall.TabStop = false;
            this.gbxOverall.Text = "Overall Scores:";
            // 
            // txtOverall
            // 
            this.txtOverall.Location = new System.Drawing.Point(6, 33);
            this.txtOverall.Multiline = true;
            this.txtOverall.Name = "txtOverall";
            this.txtOverall.ReadOnly = true;
            this.txtOverall.Size = new System.Drawing.Size(248, 133);
            this.txtOverall.TabIndex = 3;
            // 
            // gbxIndividual
            // 
            this.gbxIndividual.Controls.Add(this.txtIndividual);
            this.gbxIndividual.Location = new System.Drawing.Point(39, 25);
            this.gbxIndividual.Name = "gbxIndividual";
            this.gbxIndividual.Size = new System.Drawing.Size(276, 258);
            this.gbxIndividual.TabIndex = 1;
            this.gbxIndividual.TabStop = false;
            this.gbxIndividual.Text = "Individual Scores:";
            // 
            // txtIndividual
            // 
            this.txtIndividual.Location = new System.Drawing.Point(7, 33);
            this.txtIndividual.Multiline = true;
            this.txtIndividual.Name = "txtIndividual";
            this.txtIndividual.ReadOnly = true;
            this.txtIndividual.Size = new System.Drawing.Size(245, 133);
            this.txtIndividual.TabIndex = 0;
            // 
            // lblEasyStage
            // 
            this.lblEasyStage.AutoSize = true;
            this.lblEasyStage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEasyStage.Location = new System.Drawing.Point(345, 17);
            this.lblEasyStage.Name = "lblEasyStage";
            this.lblEasyStage.Size = new System.Drawing.Size(201, 20);
            this.lblEasyStage.TabIndex = 4;
            this.lblEasyStage.Text = "Easy Questions Completed";
            // 
            // frmMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 345);
            this.Controls.Add(this.tbcMatchtheFacts);
            this.Name = "frmMatch";
            this.Text = "Match the Facts:";
            this.tbcMatchtheFacts.ResumeLayout(false);
            this.tbcSplashScreen.ResumeLayout(false);
            this.tbcSplashScreen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tbcIntroduction.ResumeLayout(false);
            this.tbcIntroduction.PerformLayout();
            this.tbcDifficulty.ResumeLayout(false);
            this.tbcDifficulty.PerformLayout();
            this.tbcEasy.ResumeLayout(false);
            this.tbcEasy.PerformLayout();
            this.tbcQ1.ResumeLayout(false);
            this.tbcQ1.PerformLayout();
            this.tbcQ2.ResumeLayout(false);
            this.tbcQ2.PerformLayout();
            this.tbcQ3.ResumeLayout(false);
            this.tbcQ3.PerformLayout();
            this.tbcEasyCompletion.ResumeLayout(false);
            this.tbcEasyCompletion.PerformLayout();
            this.tbcHard.ResumeLayout(false);
            this.tbcHard.PerformLayout();
            this.tbcHardQ1.ResumeLayout(false);
            this.tbcHardQ1.PerformLayout();
            this.tbcHardQ2.ResumeLayout(false);
            this.tbcHardQ2.PerformLayout();
            this.tbcHardQ3.ResumeLayout(false);
            this.tbcHardQ3.PerformLayout();
            this.tbcLeaderboard.ResumeLayout(false);
            this.gbxOverall.ResumeLayout(false);
            this.gbxOverall.PerformLayout();
            this.gbxIndividual.ResumeLayout(false);
            this.gbxIndividual.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcMatchtheFacts;
        private System.Windows.Forms.TabPage tbcIntroduction;
        private System.Windows.Forms.TabPage tbcDifficulty;
        private System.Windows.Forms.TabPage tbcEasy;
        private System.Windows.Forms.TabPage tbcHard;
        private System.Windows.Forms.Button btnProceedtoDifficulty;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHard;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.TabPage tbcQ1;
        private System.Windows.Forms.TabPage tbcQ2;
        private System.Windows.Forms.TabPage tbcQ3;
        private System.Windows.Forms.Button btnProceed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEasy1;
        private System.Windows.Forms.RadioButton rbtnChoice1;
        private System.Windows.Forms.RadioButton rbtnChoice4;
        private System.Windows.Forms.RadioButton rbtnChoice3;
        private System.Windows.Forms.RadioButton rbtnChoice2;
        private System.Windows.Forms.Button btnProceedQ2;
        private System.Windows.Forms.TabPage tbcLeaderboard;
        private System.Windows.Forms.GroupBox gbxOverall;
        private System.Windows.Forms.GroupBox gbxIndividual;
        private System.Windows.Forms.RadioButton rbtnChoice6;
        private System.Windows.Forms.RadioButton rbtnChoice7;
        private System.Windows.Forms.RadioButton rbtnChoice8;
        private System.Windows.Forms.RadioButton rbtnChoice5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblEasy2;
        private System.Windows.Forms.Button btnFinalEasy;
        private System.Windows.Forms.Label lblEasy3;
        private System.Windows.Forms.Button btnFinalEasyQuestion;
        private System.Windows.Forms.RadioButton rbtnChoice12;
        private System.Windows.Forms.RadioButton rbtnChoice11;
        private System.Windows.Forms.RadioButton rbtnChoice10;
        private System.Windows.Forms.RadioButton rbtnChoice9;
        private System.Windows.Forms.TextBox txtEasyFinal;
        private System.Windows.Forms.TabPage tbcEasyCompletion;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnProceedtoMedium;
        private System.Windows.Forms.TextBox txtOverall;
        private System.Windows.Forms.TextBox txtIndividual;
        private System.Windows.Forms.TabPage tbcHardQ1;
        private System.Windows.Forms.TabPage tbcHardQ2;
        private System.Windows.Forms.TabPage tbcHardQ3;
        private System.Windows.Forms.Label lblHardQ1;
        private System.Windows.Forms.TextBox txtHardQ1;
        private System.Windows.Forms.RadioButton rbtnChoice16;
        private System.Windows.Forms.RadioButton rbtnChoice15;
        private System.Windows.Forms.RadioButton rbtnChoice14;
        private System.Windows.Forms.RadioButton rbtnChoice13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnProceedtoHard;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnNextQuestion;
        private System.Windows.Forms.RadioButton rbtnChoice20;
        private System.Windows.Forms.RadioButton rbtnChoice18;
        private System.Windows.Forms.RadioButton rbtnChoice19;
        private System.Windows.Forms.RadioButton rbtnChoice17;
        private System.Windows.Forms.TextBox txtHardQ2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFinalQuestion;
        private System.Windows.Forms.Button btnLeaderboard;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbtnChoice24;
        private System.Windows.Forms.RadioButton rbtnChoice23;
        private System.Windows.Forms.RadioButton rbtnChoice22;
        private System.Windows.Forms.RadioButton rbtnChoice21;
        private System.Windows.Forms.Button btnAccessLeaderboard;
        private System.Windows.Forms.TabPage tbcSplashScreen;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblGame;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnProceedtoGame;
        private System.Windows.Forms.Label lblEasyStage;
    }
}

