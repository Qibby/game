﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    public partial class frmMatch : Form
    {
        public frmMatch()
        {
            InitializeComponent();
        }

        //List<string> Questions = new List<string>();

        private void btnProceedtoDifficulty_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcDifficulty;
        }

        private void btnEasy_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcEasy;
        }

        private void btnProceed_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcQ1;
        }

        private void btnHard_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcHard;
        }

        private void btnProceedQ2_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcQ2;
        }

        private void btnFinalEasy_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcQ3;
        }

        private void btnClose_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        private void btnFinalEasyQuestion_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcEasyCompletion;
        }

        private void btnProceedtoMedium_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcHard;
        }

        private void btnProceedtoHard_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcHardQ1;
        }

        private void btnFinalQuestion_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcHardQ3;
        }

        private void btnLeaderboard_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcLeaderboard;
        }

        private void btnAccessLeaderboard_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcLeaderboard;
        }

        private void btnNextQuestion_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcHardQ2;
        }

        //private void pictureBox1_Click(object sender, EventArgs e)
        //{
            //pictureBox1.Image = MyGame.Properties.Resources.match_the_facts_logo;
        //}

        private void Leaderboard()
        {
            for (int i = 0; i < MyGame.Properties.Settings.Default.IndividualScore.Count; i++)
            {
               txtIndividual.AppendText(MyGame.Properties.Settings.Default.IndividualScore[i].ToString());
            }
            for (int i = 0; i < MyGame.Properties.Settings.Default.OverallScore.Count; i++)
            {
                txtOverall.AppendText(MyGame.Properties.Settings.Default.OverallScore[i].ToString());
            }
        }

        private void AddingtoCurrentscore()
        {
            switch (MyGame.Properties.Settings.Default.CurrentScore)
            {
                case 1:
                    MyGame.Properties.Settings.Default.CurrentScore += 10;
                    break;
                case 2:
                    MyGame.Properties.Settings.Default.CurrentScore += 20;
                    break;
                case 3:
                    MyGame.Properties.Settings.Default.CurrentScore += 30;
                    break;
            }
        }

        private void MinusFromScore()
        {
            switch (MyGame.Properties.Settings.Default.CurrentScore)
            {
                case 1:
                    MyGame.Properties.Settings.Default.CurrentScore -= 10;
                    break;
                case 2:
                    MyGame.Properties.Settings.Default.CurrentScore -= 20;
                    break;
                case 3:
                    MyGame.Properties.Settings.Default.CurrentScore -= 30;
                    break;
            }
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetterOrDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void btnProceedtoGame_MouseClick(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcIntroduction;
        }

        private void btnLeaderboard_MouseClick_1(object sender, MouseEventArgs e)
        {
            tbcMatchtheFacts.SelectedTab = tbcLeaderboard;
        }

    }
}
